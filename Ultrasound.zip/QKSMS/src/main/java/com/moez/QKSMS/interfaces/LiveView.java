package com.moez.QKSMS.interfaces;

public interface LiveView {
    void refresh(String key);
}
