package com.moez.QKSMS.receiver;

public class SmsReceiver extends MessagingReceiver {
}

